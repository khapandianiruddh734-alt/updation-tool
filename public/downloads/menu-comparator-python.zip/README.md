# Menu Price Comparator — Python edition

Drop-in script that mirrors the web app but adds OCR (images), PDF, and Word support
plus full openpyxl styling (yellow/green/red fills, frozen header, autofilter).

## Install

```bash
pip install -r requirements.txt
# OCR also needs the tesseract binary:
#   macOS:    brew install tesseract
#   Ubuntu:   sudo apt install tesseract-ocr
```

## Run

```bash
python compare.py --source menu.pdf --target swiggy_export.csv --out updated.xlsx
python compare.py --source menu.jpg --target zomato.csv --threshold 80
```

## Supported source formats
`.jpg .jpeg .png .bmp .tiff .pdf .docx .xlsx .xls .csv .txt`

## Output
- Original CSV columns preserved exactly
- Single new column **Update Remarks** inserted after `Goods/Services`
- Updated price cells filled yellow, unchanged-but-matched green, no-match red
- Frozen header, autofilter, 80% zoom
