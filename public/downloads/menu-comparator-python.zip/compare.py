#!/usr/bin/env python3
"""
Menu Price Comparator - Python edition
Supports: images (.jpg/.png/...), PDF, .docx, .xlsx, .csv, .txt source menus
Target: Swiggy/Zomato CSV export
Output: Updated .xlsx with yellow-highlighted price changes + Update Remarks column
"""
import argparse, os, re, sys
from difflib import SequenceMatcher
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment

YELLOW = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
GREEN = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
RED   = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
HEADER_FILL = PatternFill(start_color="E6E6E6", end_color="E6E6E6", fill_type="solid")

COMMON_TYPOS = {
    "patato":"potato","panner":"paneer","chinesse":"chinese","tandori":"tandoori",
    "tanduri":"tandoori","gril":"grill","chessis":"cheese","allu":"aloo",
    "malyi":"malai","sous":"sauce","toping":"topping","sidu":"siddu",
    "metha":"meetha","champ":"chaap","form house":"farm house",
}
EXCLUDE = {"with","and","sauce","special","new","combo"}
VAR_KW = ["half","full","large","small","regular","6 pcs","12 pcs","6pcs","12pcs","with ice cream"]

PATTERNS = [
    re.compile(r"^([A-Z][A-Z\s&'\-()]+?)\s+(\d{2,5})/-?\s*$"),
    re.compile(r"^([A-Z][A-Z\s&'\-()]+?)\s+₹\s*(\d{2,5})\s*$"),
    re.compile(r"^([A-Z][A-Z\s&'\-()]+?)\s+(\d{2,5})\s*$"),
    re.compile(r"^([A-Z][A-Z\s&'\-()]+?)\s*[-–]\s*₹?\s*(\d{2,5})\s*$"),
    re.compile(r"^\d+[).\]]?\s*([A-Z][A-Z\s&'\-()]+?)\s+₹?\s*(\d{2,5})\s*$"),
]

RULES = {"half":55,"small":65,"large":115,"sixPcs":60,"withIceCream":25}

def normalize(name):
    if not name: return ""
    s = name.lower()
    s = re.sub(r"\([^)]*\)"," ",s)
    s = re.sub(r"[^a-z0-9\s]"," ",s)
    for k in sorted(COMMON_TYPOS, key=len, reverse=True):
        s = re.sub(rf"\b{k}\b", COMMON_TYPOS[k], s)
    for v in VAR_KW:
        s = re.sub(rf"\b{v}\b"," ",s)
    return " ".join(w for w in s.split() if w not in EXCLUDE).strip()

def extract_text_lines(text):
    items = []
    for raw in text.splitlines():
        line = raw.strip()
        if len(line) < 3: continue
        for re_ in PATTERNS:
            m = re_.match(line)
            if m:
                groups = m.groups()
                name, price = groups[-2].strip(), int(groups[-1])
                if 0 < price < 100000: items.append((name, price))
                break
    seen = set(); out = []
    for n,p in items:
        k = n.lower()
        if k in seen: continue
        seen.add(k); out.append((n,p))
    return out

def extract_from_image(path):
    try:
        import pytesseract
        from PIL import Image, ImageOps
        img = ImageOps.grayscale(Image.open(path))
        return extract_text_lines(pytesseract.image_to_string(img))
    except Exception as e:
        print(f"[ocr] pytesseract failed: {e}; trying easyocr", file=sys.stderr)
        import easyocr
        r = easyocr.Reader(["en"])
        text = "\n".join(r.readtext(str(path), detail=0))
        return extract_text_lines(text)

def extract_from_pdf(path):
    try:
        import pdfplumber
        text = ""
        with pdfplumber.open(path) as pdf:
            for p in pdf.pages: text += (p.extract_text() or "") + "\n"
        return extract_text_lines(text)
    except Exception:
        from PyPDF2 import PdfReader
        text = ""
        for p in PdfReader(str(path)).pages: text += (p.extract_text() or "") + "\n"
        return extract_text_lines(text)

def extract_from_docx(path):
    import docx
    d = docx.Document(str(path))
    return extract_text_lines("\n".join(p.text for p in d.paragraphs))

def extract_from_excel(path):
    items = []
    xls = pd.ExcelFile(path)
    for sn in xls.sheet_names:
        df = xls.parse(sn).fillna("")
        cols = list(df.columns)
        name_c = next((c for c in cols if re.search(r"item|product|name|dish", str(c), re.I)), None)
        price_c = next((c for c in cols if re.search(r"price|rate|amount|mrp|cost", str(c), re.I)), None)
        if name_c and price_c:
            for _, r in df.iterrows():
                try: p = int(float(re.sub(r"[^0-9.]","", str(r[price_c]) or "0")))
                except: p = 0
                n = str(r[name_c]).strip()
                if n and p > 0: items.append((n,p))
        items += extract_text_lines(df.to_csv(index=False))
    seen = set(); out = []
    for n,p in items:
        k = n.lower()
        if k in seen: continue
        seen.add(k); out.append((n,p))
    return out

def extract_source(path):
    p = Path(path); ext = p.suffix.lower()
    if ext in {".jpg",".jpeg",".png",".bmp",".tiff"}: return extract_from_image(p)
    if ext == ".pdf": return extract_from_pdf(p)
    if ext == ".docx": return extract_from_docx(p)
    if ext in {".xlsx",".xls"}: return extract_from_excel(p)
    if ext == ".txt": return extract_text_lines(p.read_text(encoding="utf-8", errors="ignore"))
    if ext == ".csv":
        df = pd.read_csv(p).fillna("")
        return extract_from_excel(p) if False else extract_text_lines(df.to_csv(index=False))
    raise ValueError(f"Unsupported source: {ext}")

def fuzzy_match(name, items, threshold=75):
    nq = normalize(name)
    if not nq: return None, 0, False
    best, bs = None, 0
    for n, p in items:
        nn = normalize(n)
        s = max(SequenceMatcher(None, nq, nn).ratio(),
                SequenceMatcher(None, nq, nn).quick_ratio()) * 100
        if s > bs: bs, best = s, (n, p)
    if bs < threshold: return None, bs, False
    close = sum(1 for n,_ in items
                if SequenceMatcher(None, nq, normalize(n)).ratio()*100 >= bs - 5)
    return best, bs, close > 1

def is_parent(price, variation, item_type):
    v = (variation or "").strip().lower(); t = (item_type or "").strip().lower()
    return price == 0 or v in ("","item") or t == "item"

def variation_price(base, variation, rules=RULES):
    v = (variation or "").lower()
    if not v or v in ("full","regular","12 pcs","12pcs"): return base
    if v == "half":  return round(base * rules["half"]/100)
    if v == "small": return round(base * rules["small"]/100)
    if v == "large": return round(base * rules["large"]/100)
    if v in ("6 pcs","6pcs"): return round(base * rules["sixPcs"]/100)
    if "ice cream" in v: return base + rules["withIceCream"]
    return base

def detect_var(item_name, variation):
    v = (variation or "").strip().lower()
    if v and v != "item": return v
    m = re.search(r"\(([^)]+)\)", item_name or "")
    return m.group(1).strip().lower() if m else ""

def detect_col(headers, patterns):
    for p in patterns:
        for h in headers:
            if re.search(p, str(h), re.I): return h
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--target", required=True, help="Swiggy/Zomato CSV")
    ap.add_argument("--out", default="updated_menu.xlsx")
    ap.add_argument("--threshold", type=int, default=75)
    args = ap.parse_args()

    print(f"[1/3] Extracting source from {args.source}…")
    items = extract_source(args.source)
    print(f"      Found {len(items)} items")

    print(f"[2/3] Reading target CSV {args.target}…")
    # delimiter sniff
    with open(args.target, "rb") as f:
        head = f.read(4096).decode("utf-8", errors="ignore")
    delim = ";" if head.split("\n",1)[0].count(";") > head.split("\n",1)[0].count(",") else ","
    df = pd.read_csv(args.target, delimiter=delim, dtype=str, keep_default_na=False)
    headers = list(df.columns)
    name_c = detect_col(headers, [r"^item\s*name$", r"item", r"name"])
    var_c = detect_col(headers, [r"^variation$", r"variant"]) or ""
    price_c = detect_col(headers, [r"^price$", r"price"])
    type_c = detect_col(headers, [r"^item\s*type$", r"type"]) or ""
    goods_c = detect_col(headers, [r"goods\s*/?\s*services"])
    if not price_c or not name_c:
        sys.exit(f"Could not detect price/name columns in {headers}")

    print(f"      Mapped: name={name_c} price={price_c} variation={var_c} type={type_c}")
    print("[3/3] Building output…")

    insert_at = headers.index(goods_c) + 1 if goods_c else len(headers)
    out_headers = headers[:insert_at] + ["Update Remarks"] + headers[insert_at:]

    wb = Workbook(); ws = wb.active; ws.title = "Updated Menu"
    ws.append(out_headers)
    for c in ws[1]:
        c.font = Font(bold=True); c.fill = HEADER_FILL
        c.alignment = Alignment(horizontal="center", vertical="center")

    updated = unchanged = nomatch = parents = 0
    for _, row in df.iterrows():
        try: old = int(float(re.sub(r"[^0-9.]","", str(row[price_c]) or "0")))
        except: old = 0
        item = row[name_c]; var = detect_var(item, row.get(var_c,""))
        itype = row.get(type_c,"")
        out_row = [row[h] for h in headers]; remarks = ""; new_price = old; status = ""
        if is_parent(old, row.get(var_c,""), itype):
            remarks = "Parent row - kept unchanged (price 0)"; parents += 1; status = "parent"
        else:
            best, score, multi = fuzzy_match(item, items, args.threshold)
            if not best:
                remarks = "⚠️ No match found in source menu"; nomatch += 1; status = "nomatch"
            else:
                new_price = variation_price(best[1], var)
                if new_price == old:
                    remarks = "Variation row - price unchanged"; unchanged += 1; status = "unchanged"
                else:
                    pre = "⚠️ Multiple matches, used best — " if multi else ""
                    remarks = f"{pre}Price updated: ₹{old} → ₹{new_price}"
                    out_row[headers.index(price_c)] = new_price
                    updated += 1; status = "updated"
        out_row = out_row[:insert_at] + [remarks] + out_row[insert_at:]
        ws.append(out_row)
        r = ws.max_row
        if status == "updated":
            ws.cell(r, headers.index(price_c) + 1 + (1 if insert_at <= headers.index(price_c) else 0)).fill = YELLOW
        elif status == "unchanged":
            ws.cell(r, insert_at + 1).fill = GREEN
        elif status == "nomatch":
            ws.cell(r, insert_at + 1).fill = RED

    # widths, freeze, filter, zoom
    for i, h in enumerate(out_headers, 1):
        maxlen = max([len(str(h))] + [len(str(ws.cell(r,i).value or "")) for r in range(2, min(ws.max_row+1, 200))])
        ws.column_dimensions[ws.cell(1,i).column_letter].width = min(50, max(12, maxlen + 2))
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    ws.sheet_view.zoomScale = 80

    wb.save(args.out)
    print(f"\nDone → {args.out}")
    print(f"  Updated:    {updated}")
    print(f"  Unchanged:  {unchanged}")
    print(f"  No match:   {nomatch}")
    print(f"  Parent:     {parents}")

if __name__ == "__main__":
    main()
